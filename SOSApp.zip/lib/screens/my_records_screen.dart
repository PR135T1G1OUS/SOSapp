import 'package:flutter/material.dart';

class MyRecordsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Records")),
      body: Center(
        child: Text("User records will be displayed here"),
      ),
    );
  }
}
