import 'package:flutter/material.dart';

class HomeDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home Dashboard")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Welcome to SOS App"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/emergency');
              },
              child: Text("Go to Emergency Alert"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/mapdetail');
              },
              child: Text("View Map Detail"),
            ),
          ],
        ),
      ),
    );
  }
}
