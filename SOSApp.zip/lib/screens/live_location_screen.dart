import 'package:flutter/material.dart';

class LiveLocationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Live Location")),
      body: Center(
        child: Text("Live Location Map Here"),
      ),
    );
  }
}
