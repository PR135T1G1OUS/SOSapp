import 'package:flutter/material.dart';

class MapDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Map Details")),
      body: Center(
        child: Text("Detailed map view here"),
      ),
    );
  }
}
