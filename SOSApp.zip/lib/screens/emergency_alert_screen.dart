import 'package:flutter/material.dart';

class EmergencyAlertScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Emergency Alert")),
      body: Center(
        child: Text("Trigger emergency alerts here"),
      ),
    );
  }
}
